# Test stuff, because WingZ testing is just broken.

import test_call_before
import test_call_if2
import test_call_if
import test_call_instead
import test_call_once
import test_make_call_if
import test_make_call_instead
import test_log
import test_make_call_once
import test_dict_as_called
import test_pre_post
import test_invariants

