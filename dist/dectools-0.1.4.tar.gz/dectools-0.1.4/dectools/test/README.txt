See test_all.py for an explanation of tests for this project.
Run test_all.py to execute all the tests.